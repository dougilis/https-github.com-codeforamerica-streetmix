import Menu from './menu'

export let identityMenu = new Menu('identity')
