module.exports = require('requireindex')(__dirname)
