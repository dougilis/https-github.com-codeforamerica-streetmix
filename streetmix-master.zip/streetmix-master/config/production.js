module.exports = {
  app_host_port: 'streetmix.net',
  header_host_port: 'streetmix.net',
  restapi: {
    baseuri: '/api'
  },
  facebook_app_id: '162729607241489',
  google_analytics_account: 'UA-38087461-1'
}
