module.exports = {
  app_host_port: 'streetmix-staging.herokuapp.com',
  header_host_port: 'streetmix-staging.herokuapp.com',
  restapi: {
    baseuri: '/api'
  },
  facebook_app_id: '175861739245183'
}
