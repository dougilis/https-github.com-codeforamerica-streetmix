process.env.NODE_ENV = 'test'

// run tests
require('./api.v1.translate.js')
require('./api.v1.feedback.js')
